# Stack Algorithms Project

This repository contains simple C++ programs demonstrating stack operations and several stack-related interview problems. The code is written in a beginner-friendly style with lots of comments so someone new to C++ and data structures can understand and run it.

---

## Structure (single-file per problem)

- stack_menu.cpp — Menu-driven stack implementation using std::stack<int>
- reverse_using_stack.cpp — Reverse a string using a stack
- balanced_parentheses.cpp — Check if an expression has balanced parentheses
- infix_to_postfix.cpp — Convert infix expression to postfix
- evaluate_postfix.cpp — Evaluate a postfix expression
- nearest_smaller.cpp — Nearest smaller element for each array element (index smaller than current)
- min_stack.cpp — Design a stack that supports getMin() in O(1) time and O(1) extra space
- next_greater.cpp — Next Greater Element for each element
- daily_temperatures.cpp — LeetCode Daily Temperatures problem solution

---

## How to compile & run

```bash
g++ stack_menu.cpp -o stack_menu
./stack_menu
```
